<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use View;
use App\Eventos;

class EventosViewController extends Controller
{
    public function index() {
      $eventos = Eventos::all();
      return View::make("eventos", array('eventos' => $eventos));
    }
}
