<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

use App\Eventos;

class EventosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Eventos::all();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $eventos = new Eventos();
        $eventos->numeroEvento = Input::get("numeroEvento");
        $eventos->numeroBoletos = Input::get("numeroBoletos");
        $eventos->ANombreD = Input::get("ANombreD");
        $eventos->Tipo = Input::get("Tipo");
        $eventos->description = Input::get("description");
        $eventos->save();

        return response()->json([
          "response" => "Saved"
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $eventos = Eventos::where("numeroEvento",$id)->get();
        return eventos;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return response()->json([
          "response" => "Enabled"
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $eventos = Eventos::where("ANombreD",$id)->orWhere("numeroBoletos", $id)->first();
        $eventos->save();

        return response()->json([
          "response" => "Updated"
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        \App\Eventos::destroy($id);
        return response()->json([
          "response" => "Deleted"
        ], 200);
    }
}
