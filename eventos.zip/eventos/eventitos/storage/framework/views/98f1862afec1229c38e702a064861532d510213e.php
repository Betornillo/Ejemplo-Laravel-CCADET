<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Eliminar Eventos</title>
    <style media="screen">
      form{
        width: 100%;
      }
      input, label{
        display: inline-block;
        width: 60%;
        height: 20px;
        margin-left: 20%
      }
      button{
        display: inline-block;
        width: 30%;
        height: 30px;
        margin-left: 35%;
      }
    </style>
  </head>
  <body>
    <h1 style="text-align: center">Eliminar eventos</h1>
    <form action="/api/eventos" method="delete">
      <input type="number" name="id" placeholder="Numero de registro del evento">
      <button type="submit" name="button">Eliminar Evento</button>
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    </form>
  </body>
</html>
