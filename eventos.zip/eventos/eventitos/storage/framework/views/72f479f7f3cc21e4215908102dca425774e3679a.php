<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Eventos</title>
    <style media="screen">
    table {
      width: 80%;
      margin-left: 10%;
      text-align: center;
      border: solid black 1px;
    }
    </style>
  </head>
  <body>
    <table>
    <thead>
      <th>Id</th>
      <th>Nombre del evento</th>
      <th>Tipo de asiento</th>
      <th>Descripcion</th>
      <th>Numero de boletos</th>
      <th>Numero registro evento</th>
    </thead>

    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr style="background-color: #<?php echo e(000000); ?>">
      <td><?php echo e($evento->id); ?></td>
      <td><?php echo e($evento->ANombreD); ?></td>
      <td><?php echo e($evento->Tipo); ?></td>
      <td><?php echo e($evento->description); ?></td>
      <td><?php echo e($evento->numeroBoletos); ?></td>
      <td><?php echo e($evento->numeroEvento); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</body>
</html>
