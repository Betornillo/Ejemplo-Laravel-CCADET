<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Crear Eventos</title>
    <style media="screen">
      form{
        width: 100%;
      }
      input, label{
        display: inline-block;
        width: 60%;
        height: 20px;
        margin-left: 20%
      }
      button{
        display: inline-block;
        width: 30%;
        height: 30px;
        margin-left: 35%;
      }
    </style>
  </head>
  <body>
    <h1 style="text-align: center">Crear eventos</h1>
    <form action="/api/eventos" method="post">
      <input type="number" name="numeroEvento" placeholder="Numero de registro del evento">
      <input type="number" name="numeroBoletos" placeholder="Numero de Boletos">
      <input type="text" name="ANombreD" placeholder="Nombre del evento">
      <input type="text" name="Tipo" placeholder="tipo de asiento">
      <input type="text" name="description" placeholder="descripcion del evento">
      <button type="submit" name="button">Guardar Evento</button>
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    </form>
  </body>
</html>
