<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Eventos</title>
    <style media="screen">
    table {
      width: 80%;
      margin-left: 10%;
      text-align: center;
      border: solid black 1px;
    }
    </style>
  </head>
  <body>
    <table>
    <thead>
      <th>Id</th>
      <th>Nombre del evento</th>
      <th>Tipo de asiento</th>
      <th>Descripcion</th>
      <th>Numero de boletos</th>
      <th>Numero registro evento</th>
    </thead>

    @foreach($eventos as $evento)
    <tr style="background-color: #{{000000}}">
      <td>{{$evento->id }}</td>
      <td>{{$evento->ANombreD}}</td>
      <td>{{$evento->Tipo}}</td>
      <td>{{$evento->description}}</td>
      <td>{{$evento->numeroBoletos}}</td>
      <td>{{$evento->numeroEvento}}</td>
    </tr>
    @endforeach
  </table>
</body>
</html>
